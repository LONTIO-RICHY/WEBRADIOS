// ChainesGauche.jsx — Liste des chaînes (colonne gauche)
// Chaque chaîne est un lien React Router vers /chaines/:id
// La colonne droite (ChainesDroite) lit l'id dans l'URL via useParams()

import { Link, useParams } from "react-router-dom";
import { Search, Radio, Compass, UserCircle } from "@boxicons/react";
import { useEffect, useState } from "react";
import api from "../Api";
import { useAuth } from "../context/AuthContext";

export default function ChainesGauche() {
  const { id } = useParams();
  const { user } = useAuth();
  const [mesChaines, setMesChaines] = useState([]);
  const [toutesLesChaines, setToutesLesChaines] = useState([]);
  const [search, setSearch] = useState("");

  useEffect(() => {
    const fetchChannels = async () => {
      try {
        const resAll = await api.get("/api/channels");
        setToutesLesChaines(resAll.data);

        if (user) {
          const resMy = await api.get("/api/my-channels", {
            headers: { Authorization: `Bearer ${user.token}` }
          });
          setMesChaines(resMy.data);
        }
      } catch (err) {
        console.error("Erreur chargement des chaînes", err);
      }
    };
    fetchChannels();
  }, [user]);

  const filteredChannels = toutesLesChaines.filter(c => 
    c.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="flex flex-col h-screen bg-slate-50 border-r border-slate-200">
      <div className="p-6">
        <h2 className="text-xl font-black text-slate-900 flex items-center gap-2 mb-6">
          <div className="p-2 bg-indigo-600 rounded-lg shadow-lg shadow-indigo-100">
            <Radio className="text-white" size={20} />
          </div>
          Exploration
        </h2>

        <div className="relative group">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-500 transition-colors" size={18} />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Rechercher une chaîne..."
            className="w-full pl-10 pr-4 py-3 text-sm bg-white border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all shadow-sm"
          />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-4 pb-10 space-y-6">
        {/* Mes Chaînes Créées */}
        {user && mesChaines.length > 0 && (
          <div className="animate-in fade-in slide-in-from-left-4 duration-500">
            <p className="px-2 mb-3 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Mes Propriétés</p>
            <div className="space-y-2">
              {mesChaines.map((c) => (
                <Link to={`/ChannelDashboard/${c.id}`} key={`my-${c.id}`}>
                  <div className="flex items-center gap-3 p-3 rounded-2xl cursor-pointer transition-all border border-indigo-100 bg-white hover:shadow-lg hover:shadow-indigo-100/50 group">
                    <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white text-sm font-bold shadow-md group-hover:scale-110 transition-transform">
                      {c.name.charAt(0).toUpperCase()}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-bold text-slate-900 truncate">{c.name}</p>
                      <p className="text-[10px] text-indigo-600 font-black tracking-widest uppercase">Admin</p>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}

        {/* Toutes les chaînes */}
        <div className="animate-in fade-in slide-in-from-left-4 duration-700">
          <p className="px-2 mb-3 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] flex items-center gap-2">
             <Compass size={12} /> Découvrir
          </p>
          <div className="space-y-2">
            {filteredChannels.length > 0 ? (
              filteredChannels.map((c) => {
                const estActif = String(c.id) === id;
                return (
                  <Link to={`/Chaines/${c.id}`} key={c.id}>
                    <div className={`flex items-center gap-3 p-3 rounded-2xl cursor-pointer transition-all border
                      ${estActif 
                        ? "bg-indigo-600 border-indigo-600 shadow-xl shadow-indigo-200 translate-x-1" 
                        : "bg-white border-slate-100 hover:border-indigo-200 hover:shadow-md"}`}>
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-sm font-bold transition-colors
                        ${estActif ? "bg-white text-indigo-600" : "bg-slate-100 text-slate-600"}`}>
                        {c.name.charAt(0).toUpperCase()}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className={`text-sm font-bold truncate ${estActif ? "text-white" : "text-slate-900"}`}>
                          {c.name}
                        </p>
                        <p className={`text-[10px] font-medium ${estActif ? "text-indigo-100" : "text-slate-400"}`}>
                          {c.owner_name}
                        </p>
                      </div>
                    </div>
                  </Link>
                );
              })
            ) : (
              <div className="text-center py-10">
                <p className="text-sm text-slate-400 font-medium">Aucune chaîne trouvée</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
