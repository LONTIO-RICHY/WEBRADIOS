import { useState, useRef, useEffect } from "react";

function Player() {
  const [isListening, setIsListening] = useState(false);
  const [statusMessage, setStatusMessage] = useState("Écouter un streaming en direct");
  
  const socketRef = useRef(null);
  const audioCtxRef = useRef(null);
  const nextStartTimeRef = useRef(0); // Pour enchaîner les sons de manière fluide

  // Remplace par ton IP locale pour les tests réseau (ex: "192.168.1.50")
  const IP_LOCALE = "127.0.0.1"; 

  const startStreaming = async () => {
    setStatusMessage("Connexion au direct...");

    // 1. Initialiser le décodeur de son brut du navigateur
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    const audioCtx = new AudioContext({ sampleRate: 44100 }); // Fréquence standard CD
    audioCtxRef.current = audioCtx;
    nextStartTimeRef.current = audioCtx.currentTime;

    // 2. Connexion WebSocket
    const socket = new WebSocket(`ws://${IP_LOCALE}:8000/ws/stream`);
    socketRef.current = socket;
    socket.binaryType = "arraybuffer"; // On reçoit des données binaires brutes

    socket.onopen = () => {
      setStatusMessage("● EN DIRECT");
      setIsListening(true);
    };

    // 3. RÉCEPTION DES FRÉQUENCES
    socket.onmessage = (event) => {
      if (!audioCtx || audioCtx.state === "suspended") return;

      // Convertir les données binaires reçues en tableau de fréquences (Float32)
      const arrayBuffer = event.data;
      const float32Array = new Float32Array(arrayBuffer);

      // Créer un mini-buffer audio dans le navigateur
      const audioBuffer = audioCtx.createBuffer(1, float32Array.length, 44100);
      audioBuffer.getChannelData(0).set(float32Array);

      // Créer la source de lecture
      const source = audioCtx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(audioCtx.destination);

      // Enchaîner les morceaux de son sans aucun vide (gaps)
      const currentTime = audioCtx.currentTime;
      if (nextStartTimeRef.current < currentTime) {
        nextStartTimeRef.current = currentTime;
      }

      source.start(nextStartTimeRef.current);
      nextStartTimeRef.current += audioBuffer.duration; // Préparer le début du prochain morceau
    };

    socket.onclose = () => {
      stopStreaming();
    };

    socket.onerror = (err) => {
      console.error(err);
      setStatusMessage("Erreur de connexion");
    };
  };

  const stopStreaming = () => {
    if (socketRef.current) socketRef.current.close();
    if (audioCtxRef.current) {
      audioCtxRef.current.close();
      audioCtxRef.current = null;
    }
    setStatusMessage("Écouter un streaming en direct");
    setIsListening(false);
  };

  useEffect(() => {
    return () => {
      if (socketRef.current) socketRef.current.close();
    };
  }, []);

  return (
    <div className="flex items-center gap-6 p-4 bg-white/90 backdrop-blur-xl border border-indigo-100 rounded-2xl shadow-2xl shadow-indigo-100/50 w-full animate-in slide-in-from-bottom-4 duration-500">
      <div className="flex-1 flex items-center gap-4">
        <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-white shadow-lg transition-all duration-500 ${
          isListening ? "bg-rose-500 animate-pulse scale-105 shadow-rose-200" : "bg-indigo-600 shadow-indigo-200"
        }`}>
          {isListening ? "📻" : "🎧"}
        </div>
        <div className="text-left">
          <h2 className="text-sm font-black text-slate-800 leading-tight uppercase tracking-wider">{statusMessage}</h2>
          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-0.5">
            {isListening ? "Qualité Audio HD • 44.1kHz" : "Prêt pour l'écoute"}
          </p>
        </div>
      </div>
      
      <div className="flex items-center gap-4 border-l border-slate-100 pl-6">
        <button
          onClick={isListening ? stopStreaming : startStreaming}
          className={`group relative w-12 h-12 rounded-full flex items-center justify-center text-xl font-bold text-white transition-all active:scale-90 ${
            isListening 
              ? "bg-rose-500 hover:bg-rose-600" 
              : "bg-indigo-600 hover:bg-indigo-700 shadow-lg shadow-indigo-200"
          }`}
        >
          <span className="relative z-10 transition-transform group-hover:scale-110">
            {isListening ? "⏸" : "▶"}
          </span>
          {isListening && (
            <span className="absolute inset-0 rounded-full bg-rose-500 animate-ping opacity-25"></span>
          )}
        </button>
        
        <div className="hidden sm:block text-right min-w-[120px]">
          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-tighter">
            {isListening ? "Cliquez pour arrêter" : "Lancer le direct"}
          </p>
        </div>
      </div>
    </div>
  );
}

export default Player;