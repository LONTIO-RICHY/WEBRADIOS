import { useState, useEffect } from "react";
import { useAuth } from "../context/AuthContext";
import api from "../Api";
import { User, Radio, Trash, UserPlus, UserMinus, BarChart, Cog } from "@boxicons/react";

const AdminDashboard = () => {
    const { user } = useAuth();
    const [activeTab, setActiveTab] = useState("users");
    const [users, setUsers] = useState([]);
    const [channels, setChannels] = useState([]);
    const [stats, setStats] = useState({ users: 0, channels: 0 });

    useEffect(() => {
        const fetchData = async () => {
            try {
                const [uRes, cRes, sRes] = await Promise.all([
                    api.get("/api/admin/users", { headers: { Authorization: `Bearer ${user?.token}` } }),
                    api.get("/api/admin/channels", { headers: { Authorization: `Bearer ${user?.token}` } }),
                    api.get("/api/admin/stats", { headers: { Authorization: `Bearer ${user?.token}` } })
                ]);
                setUsers(uRes.data);
                setChannels(cRes.data);
                setStats(sRes.data);
            } catch (err) {
                console.error("Erreur admin", err);
            }
        };
        if (user?.is_admin) fetchData();
    }, [user]);

    const deleteUser = async (id) => {
        if (!window.confirm("Supprimer cet utilisateur ?")) return;
        try {
            await api.delete(`/api/admin/users/${id}`, { headers: { Authorization: `Bearer ${user?.token}` } });
            setUsers(users.filter(u => u.id !== id));
        } catch (err) { alert("Erreur lors de la suppression"); }
    };

    const deleteChannel = async (id) => {
        if (!window.confirm("Supprimer cette chaîne ?")) return;
        try {
            await api.delete(`/api/admin/channels/${id}`, { headers: { Authorization: `Bearer ${user?.token}` } });
            setChannels(channels.filter(c => c.id !== id));
        } catch (err) { alert("Erreur lors de la suppression"); }
    };

    const sidebarItems = [
        { id: "stats", label: "Statistiques", icon: <BarChart /> },
        { id: "users", label: "Gestion Utilisateurs", icon: <User /> },
        { id: "channels", label: "Gestion Chaînes", icon: <Radio /> },
        { id: "settings", label: "Paramètres Globaux", icon: <Cog /> },
    ];

    return (
        <div className="flex h-screen bg-gray-900 text-white">
            {/* Sidebar Admin */}
            <div className="w-72 bg-gray-800 p-6 flex flex-col border-r border-gray-700">
                <div className="flex items-center gap-3 mb-12">
                    <div className="w-10 h-10 bg-red-600 rounded-lg flex items-center justify-center font-bold text-xl">L</div>
                    <div>
                        <h2 className="font-black text-lg">LUKO Admin</h2>
                        <p className="text-gray-400 text-xs">Console de contrôle</p>
                    </div>
                </div>

                <nav className="flex-1 space-y-2">
                    {sidebarItems.map((item) => (
                        <button
                            key={item.id}
                            onClick={() => setActiveTab(item.id)}
                            className={`w-full flex items-center gap-3 p-4 rounded-xl font-bold transition-all ${
                                activeTab === item.id 
                                ? "bg-red-600 text-white" 
                                : "text-gray-400 hover:bg-gray-700"
                            }`}
                        >
                            {item.icon} {item.label}
                        </button>
                    ))}
                </nav>
            </div>

            {/* Main Content */}
            <div className="flex-1 p-8 overflow-y-auto bg-gray-900">
                <h1 className="text-4xl font-black mb-8">Tableau de bord Administrateur</h1>

                {activeTab === "stats" && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <div className="bg-gray-800 p-8 rounded-3xl border border-gray-700">
                            <p className="text-gray-400 font-bold uppercase text-sm mb-2">Total Utilisateurs</p>
                            <p className="text-6xl font-black text-blue-500">{stats.users}</p>
                        </div>
                        <div className="bg-gray-800 p-8 rounded-3xl border border-gray-700">
                            <p className="text-gray-400 font-bold uppercase text-sm mb-2">Total Chaînes</p>
                            <p className="text-6xl font-black text-red-500">{stats.channels}</p>
                        </div>
                    </div>
                )}

                {activeTab === "users" && (
                    <div className="bg-gray-800 rounded-3xl overflow-hidden border border-gray-700">
                        <table className="w-full text-left">
                            <thead className="bg-gray-700 text-gray-300 uppercase text-xs font-bold">
                                <tr>
                                    <th className="p-4">ID</th>
                                    <th className="p-4">Utilisateur</th>
                                    <th className="p-4">Email</th>
                                    <th className="p-4">Rôle</th>
                                    <th className="p-4">Actions</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-700">
                                {users.map(u => (
                                    <tr key={u.id} className="hover:bg-gray-750">
                                        <td className="p-4 text-gray-500">{u.id}</td>
                                        <td className="p-4 font-bold">{u.username}</td>
                                        <td className="p-4 text-gray-400">{u.email}</td>
                                        <td className="p-4">
                                            {u.is_admin ? (
                                                <span className="bg-red-900 text-red-200 px-2 py-1 rounded text-xs font-bold">ADMIN</span>
                                            ) : (
                                                <span className="bg-gray-700 text-gray-300 px-2 py-1 rounded text-xs font-bold">USER</span>
                                            )}
                                        </td>
                                        <td className="p-4 flex gap-2">
                                            <button onClick={() => deleteUser(u.id)} className="p-2 bg-red-600/20 text-red-500 rounded-lg hover:bg-red-600 hover:text-white transition">
                                                <Trash />
                                            </button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}

                {activeTab === "channels" && (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {channels.map(c => (
                            <div key={c.id} className="bg-gray-800 p-6 rounded-3xl border border-gray-700 hover:border-red-500 transition-all">
                                <div className="flex justify-between items-start mb-4">
                                    <Radio className="text-red-500" size={32} />
                                    <button onClick={() => deleteChannel(c.id)} className="text-gray-500 hover:text-red-500 transition">
                                        <Trash />
                                    </button>
                                </div>
                                <h3 className="text-xl font-bold mb-2">{c.name}</h3>
                                <p className="text-gray-400 text-sm mb-4">Propriétaire : {c.owner_name}</p>
                                <div className="flex justify-between text-xs font-bold text-gray-500">
                                    <span>{c.payment_method}</span>
                                    <span>{c.amount}</span>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
};

export default AdminDashboard;
