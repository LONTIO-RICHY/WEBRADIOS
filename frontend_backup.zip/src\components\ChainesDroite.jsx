import { useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import api from "../Api";
import { Radio, Heart, Play, Calendar, InfoCircle } from "@boxicons/react";

export default function ChainesDroite() {
  const { id } = useParams();
  const [chaine, setChaine] = useState(null);
  const [emissions, setEmissions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchDetails = async () => {
      if (!id) return;
      setLoading(true);
      try {
        const resChaine = await api.get(`/api/channels/${id}`);
        setChaine(resChaine.data);

        const resEmissions = await api.get(`/api/channels/${id}/emissions`);
        setEmissions(resEmissions.data);
      } catch (err) {
        console.error("Erreur chargement détails chaîne", err);
      } finally {
        setLoading(false);
      }
    };
    fetchDetails();
  }, [id]);

  if (!id) return (
    <div className="flex flex-col items-center justify-center h-full text-slate-400 bg-slate-50">
      <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mb-4">
        <Radio size={40} className="text-slate-300" />
      </div>
      <p className="font-bold tracking-tight">Sélectionnez une chaîne pour explorer son univers</p>
    </div>
  );

  if (loading) return (
    <div className="flex items-center justify-center h-full bg-white">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
    </div>
  );

  if (!chaine) return (
    <div className="flex items-center justify-center h-full text-rose-500 font-bold">
      Chaîne introuvable
    </div>
  );

  return (
    <div className="flex flex-col h-screen overflow-y-auto bg-white">
      {/* ── Bannière Hero ── */}
      <div className="relative overflow-hidden bg-slate-900 p-8 md:p-12">
        <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-600/20 rounded-full blur-3xl -mr-32 -mt-32"></div>
        <div className="relative z-10 flex flex-col md:flex-row items-center md:items-end gap-6">
          <div className="w-32 h-32 bg-indigo-600 rounded-3xl flex items-center justify-center text-white text-4xl font-black shadow-2xl shadow-indigo-900/50 transform -rotate-3 hover:rotate-0 transition-transform duration-500">
            {chaine.name.charAt(0).toUpperCase()}
          </div>
          <div className="text-center md:text-left flex-1">
            <div className="flex items-center justify-center md:justify-start gap-3 mb-2">
              <span className="px-3 py-1 bg-rose-500 text-white text-[10px] font-black rounded-full uppercase tracking-widest flex items-center gap-1.5 shadow-lg shadow-rose-500/30">
                <span className="w-1.5 h-1.5 bg-white rounded-full animate-pulse" />
                Live Now
              </span>
              <span className="px-3 py-1 bg-white/10 text-white/70 text-[10px] font-black rounded-full uppercase tracking-widest backdrop-blur-md">
                {chaine.payment_method}
              </span>
            </div>
            <h1 className="text-4xl md:text-5xl font-black text-white tracking-tighter mb-2">{chaine.name}</h1>
            <p className="text-indigo-200/70 font-medium flex items-center justify-center md:justify-start gap-2 italic">
              <InfoCircle size={16} /> Créé par {chaine.owner_name}
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 p-8 bg-slate-50/50">
        <div className="lg:col-span-2 space-y-8">
          {/* ── Liste des Émissions ── */}
          <section>
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-black text-slate-900 tracking-tight flex items-center gap-2">
                <Calendar className="text-indigo-600" /> Emissions & Programmes
              </h3>
              <span className="text-xs font-bold text-slate-400 bg-slate-100 px-3 py-1 rounded-full uppercase tracking-widest">
                {emissions.length} émissions
              </span>
            </div>

            {emissions.length > 0 ? (
              <div className="grid grid-cols-1 gap-4">
                {emissions.map((e) => (
                  <div key={e.id} className="group flex items-center gap-4 p-4 bg-white border border-slate-100 rounded-2xl hover:border-indigo-200 hover:shadow-xl hover:shadow-indigo-100/50 transition-all">
                    <div className="w-14 h-14 bg-slate-50 rounded-xl flex items-center justify-center text-indigo-600 group-hover:bg-indigo-600 group-hover:text-white transition-colors duration-300">
                      <Play size={24} />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">{e.title}</h4>
                      <p className="text-sm text-slate-500 line-clamp-1">{e.description}</p>
                    </div>
                    <button className="px-4 py-2 bg-slate-100 text-slate-600 text-xs font-black rounded-xl hover:bg-indigo-600 hover:text-white transition-all uppercase tracking-widest">
                      Écouter
                    </button>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-10 bg-white border border-dashed border-slate-200 rounded-3xl text-center">
                <p className="text-slate-400 font-bold italic">Aucune émission programmée pour le moment</p>
              </div>
            )}
          </section>
        </div>

        <div className="space-y-6">
          {/* ── Actions & Infos Rapides ── */}
          <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
            <h4 className="font-black text-slate-900 mb-4 uppercase text-xs tracking-[0.2em] border-b border-slate-50 pb-2">Actions</h4>
            <div className="space-y-3">
              <button className="w-full flex items-center justify-center gap-2 py-4 bg-indigo-600 text-white rounded-2xl font-black text-sm shadow-xl shadow-indigo-200 hover:bg-indigo-700 hover:-translate-y-1 transition-all">
                <Play size={20} /> ÉCOUTER LE DIRECT
              </button>
              <button className="w-full flex items-center justify-center gap-2 py-4 border-2 border-slate-100 text-slate-600 rounded-2xl font-black text-sm hover:bg-slate-50 transition-all">
                <Heart size={20} /> AJOUTER AUX FAVORIS
              </button>
            </div>
          </div>

          <div className="bg-indigo-900 p-6 rounded-3xl text-white shadow-xl shadow-indigo-900/20">
            <p className="text-[10px] font-black text-indigo-300 uppercase tracking-widest mb-1">Contact Antenne</p>
            <p className="text-xl font-black tracking-tight mb-4">{chaine.phone}</p>
            <div className="p-3 bg-white/5 rounded-xl border border-white/10">
              <p className="text-[10px] text-indigo-300 font-bold leading-relaxed italic">
                Soutenez cette chaîne pour qu'elle continue de vous offrir du contenu de qualité.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
