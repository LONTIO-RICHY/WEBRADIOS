 import { useState } from "react";
 import { Search, SparklesAlt, Radio, Phone, User, CreditCard, Lock } from "@boxicons/react";
 import Listederoulante from "./Listederoulante";
 import { useAuth } from "../context/AuthContext";
 import api from "../Api";
 import { useNavigate } from "react-router-dom";

 export const Corps = () => {
     const { user } = useAuth();
     const navigate = useNavigate();
     const [formData, setFormData] = useState({
         name: "",
         phone: "",
         owner_name: "",
         amount: "",
         payment_method: "Mobile Money",
         auth_word: ""
     });
     const [loading, setLoading] = useState(false);
     const [error, setError] = useState("");

     const handleCreateChannel = async (e) => {
         e.preventDefault();
         if (!user) {
             alert("Veuillez vous connecter pour créer une chaîne");
             return;
         }

         setLoading(true);
         setError("");

         try {
             const response = await api.post("/api/channels", formData, {
                 headers: { Authorization: `Bearer ${user.token}` }
             });
             alert("Chaîne créée avec succès !");
             navigate(`/ChannelDashboard/${response.data.id}`);
         } catch (err) {
             setError(err.response?.data?.detail || "Erreur lors de la création");
         } finally {
             setLoading(false);
         }
     };

     return (
         <div className="min-h-screen bg-gray-50 pb-20">
             <span className="relative top-4 left-5">
                 <Listederoulante />
             </span>

             <div className="flex flex-col justify-center items-center pt-20 px-4 text-center">
                 <h2 className="bg-pink-500 flex p-2 rounded-full m-3 text-white font-bold shadow-lg">
                     <span className="mr-2"><SparklesAlt /></span> plus de 200 chaines disponibles
                 </h2>
                 <h1 className="text-4xl md:text-5xl font-extrabold m-3 text-gray-900">
                     Écoutez vos émissions favorites en direct
                 </h1>
                 <p className="text-xl md:text-2xl text-gray-600 m-5 max-w-2xl">
                     Découvrez des centaines de webradios thématiques et ne manquez plus jamais vos programmes préférés.
                 </p>

                 <div className="relative flex items-center justify-center gap-3 w-full max-w-lg mb-12">
                     <i className="absolute left-4 text-2xl text-gray-400">
                         <Search />
                     </i>
                     <input
                         type="text"
                         placeholder="Recherche une émission, une chaîne ou un animateur"
                         className="w-full py-4 pl-12 pr-4 rounded-2xl border-2 border-blue-100 shadow-sm focus:border-blue-500 focus:bg-white focus:outline-none transition-all"
                     />
                 </div>

                 {user && (
                     <div className="w-full max-w-2xl bg-white p-8 rounded-3xl shadow-2xl border border-gray-100 mb-20 animate-fade-in">
                         <h2 className="text-3xl font-bold text-gray-800 mb-6 flex items-center justify-center gap-3">
                             <Radio className="text-blue-600" /> Créer ma propre chaîne
                         </h2>

                         {error && (
                             <div className="bg-red-50 text-red-600 p-4 rounded-xl mb-6 font-medium">
                                 {error}
                             </div>
                         )}

                         <form onSubmit={handleCreateChannel} className="grid grid-cols-1 md:grid-cols-2 gap-6 text-left">
                             <div className="space-y-2">
                                 <label className="text-sm font-bold text-gray-700 flex items-center gap-2">
                                     <Radio size={18} /> Nom de la chaîne
                                 </label>
                                 <input
                                     required
                                     type="text"
                                     placeholder="Ma Super Radio"
                                     className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
                                     value={formData.name}
                                     onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                                 />
                             </div>

                             <div className="space-y-2">
                                 <label className="text-sm font-bold text-gray-700 flex items-center gap-2">
                                     <Phone size={18} /> Numéro de téléphone
                                 </label>
                                 <input
                                     required
                                     type="tel"
                                     placeholder="6xx xxx xxx"
                                     className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
                                     value={formData.phone}
                                     onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                                 />
                             </div>

                             <div className="space-y-2">
                                 <label className="text-sm font-bold text-gray-700 flex items-center gap-2">
                                     <User size={18} /> Votre Nom complet
                                 </label>
                                 <input
                                     required
                                     type="text"
                                     placeholder="Jean Dupont"
                                     className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
                                     value={formData.owner_name}
                                     onChange={(e) => setFormData({ ...formData, owner_name: e.target.value })}
                                 />
                             </div>

                             <div className="space-y-2">
                                 <label className="text-sm font-bold text-gray-700 flex items-center gap-2">
                                     <CreditCard size={18} /> Montant et Mode de paiement
                                 </label>
                                 <div className="flex gap-2">
                                     <input
                                         required
                                         type="text"
                                         placeholder="5000 FCFA"
                                         className="flex-1 p-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
                                         value={formData.amount}
                                         onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                                     />
                                     <select 
                                         className="p-3 bg-gray-50 border border-gray-200 rounded-xl outline-none"
                                         value={formData.payment_method}
                                         onChange={(e) => setFormData({ ...formData, payment_method: e.target.value })}
                                     >
                                         <option>Orange Money</option>
                                         <option>MTN MoMo</option>
                                         <option>Carte Bancaire</option>
                                     </select>
                                 </div>
                             </div>

                             <div className="md:col-span-2 space-y-2">
                                 <label className="text-sm font-bold text-gray-700 flex items-center gap-2">
                                     <Lock size={18} /> Mot d'authentification (Défaut: qwerty237)
                                 </label>
                                 <input
                                     required
                                     type="password"
                                     placeholder="Entrez le mot clé pour valider"
                                     className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
                                     value={formData.auth_word}
                                     onChange={(e) => setFormData({ ...formData, auth_word: e.target.value })}
                                 />
                             </div>

                             <button
                                 type="submit"
                                 disabled={loading}
                                 className="md:col-span-2 bg-blue-600 hover:bg-blue-700 text-white py-4 rounded-xl font-bold text-lg shadow-lg transform active:scale-95 transition-all disabled:opacity-50 mt-4"
                             >
                                 {loading ? "Création en cours..." : "Valider et Créer ma chaîne"}
                             </button>
                         </form>
                     </div>
                 )}
             </div>
         </div>
     );
 };