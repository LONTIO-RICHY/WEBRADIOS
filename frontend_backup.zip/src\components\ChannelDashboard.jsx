import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import api from "../Api";
import { Radio, Edit, Globe, Trash, History, Power, ArrowToTop, BarChart } from "@boxicons/react";

const ChannelDashboard = () => {
    const { id } = useParams();
    const { user } = useAuth();
    const navigate = useNavigate();
    const [channel, setChannel] = useState(null);
    const [activeTab, setActiveTab] = useState("overview");

    useEffect(() => {
        const fetchChannel = async () => {
            try {
                const response = await api.get("/api/my-channels", {
                    headers: { Authorization: `Bearer ${user?.token}` }
                });
                const myChannel = response.data.find(c => String(c.id) === id);
                if (!myChannel) {
                    navigate("/");
                } else {
                    setChannel(myChannel);
                }
            } catch (err) {
                console.error("Erreur chargement chaîne", err);
                navigate("/");
            }
        };
        if (user) fetchChannel();
    }, [id, user, navigate]);

    if (!channel) return <div className="p-10 text-center">Chargement...</div>;

    const sidebarItems = [
        { id: "overview", label: "Vue d'ensemble", icon: <BarChart /> },
        { id: "live", label: "Streaming Direct", icon: <Radio /> },
        { id: "upload", label: "Exporter Audio (PC)", icon: <ArrowToTop /> },
        { id: "history", label: "Historique", icon: <History /> },
        { id: "settings", label: "Paramètres", icon: <Edit /> },
        { id: "language", label: "Langue", icon: <Globe /> },
    ];

    return (
        <div className="flex h-screen bg-gray-100">
            {/* Main Content Area */}
            <div className="flex-1 p-8 overflow-y-auto">
                <header className="flex justify-between items-center mb-8">
                    <div>
                        <h1 className="text-3xl font-bold text-gray-800">Ma Chaîne : {channel.name}</h1>
                        <p className="text-gray-500">Gérez vos diffusions et paramétrez votre antenne</p>
                    </div>
                    <button 
                        onClick={() => navigate("/")}
                        className="flex items-center gap-2 bg-white px-4 py-2 rounded-xl shadow-sm hover:shadow-md transition text-red-600 font-bold"
                    >
                        <Power /> Quitter le Dashboard
                    </button>
                </header>

                <div className="bg-white rounded-3xl p-8 shadow-sm min-h-[500px]">
                    {activeTab === "overview" && (
                        <div className="space-y-6">
                            <h2 className="text-2xl font-bold">Bienvenue sur votre Dashboard</h2>
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                                <div className="bg-blue-50 p-6 rounded-2xl">
                                    <p className="text-blue-600 font-bold uppercase text-xs">Abonnés</p>
                                    <p className="text-4xl font-black">0</p>
                                </div>
                                <div className="bg-green-50 p-6 rounded-2xl">
                                    <p className="text-green-600 font-bold uppercase text-xs">Diffusions</p>
                                    <p className="text-4xl font-black">0</p>
                                </div>
                                <div className="bg-purple-50 p-6 rounded-2xl">
                                    <p className="text-purple-600 font-bold uppercase text-xs">Auditeurs Actuels</p>
                                    <p className="text-4xl font-black">0</p>
                                </div>
                            </div>
                        </div>
                    )}

                    {activeTab === "live" && (
                        <div className="text-center py-20">
                            <Radio size={64} className="mx-auto text-red-600 animate-pulse mb-4" />
                            <h2 className="text-2xl font-bold mb-4">Lancer un Streaming en Direct</h2>
                            <button className="bg-red-600 text-white px-8 py-3 rounded-full font-bold hover:bg-red-700 transition">
                                Démarrer l'antenne
                            </button>
                        </div>
                    )}

                    {activeTab === "upload" && (
                        <div className="text-center py-20 border-4 border-dashed border-gray-100 rounded-3xl">
                            <ArrowToTop size={64} className="mx-auto text-blue-600 mb-4" />
                            <h2 className="text-2xl font-bold mb-4">Exporter des éléments audio depuis votre PC</h2>
                            <input type="file" className="hidden" id="audio-upload" />
                            <label htmlFor="audio-upload" className="cursor-pointer bg-blue-600 text-white px-8 py-3 rounded-full font-bold hover:bg-blue-700 transition">
                                Choisir un fichier
                            </label>
                        </div>
                    )}

                    {activeTab === "settings" && (
                        <div className="max-w-md space-y-6">
                            <h2 className="text-2xl font-bold">Paramètres de la chaîne</h2>
                            <div className="space-y-2">
                                <label className="text-sm font-bold text-gray-600">Nom de la chaîne</label>
                                <input type="text" defaultValue={channel.name} className="w-full p-3 border rounded-xl" />
                            </div>
                            <button className="bg-blue-600 text-white px-6 py-2 rounded-xl font-bold">Sauvegarder</button>
                            <hr />
                            <div className="pt-4">
                                <button className="flex items-center gap-2 text-red-600 font-bold hover:underline">
                                    <Trash /> Supprimer définitivement la chaîne
                                </button>
                            </div>
                        </div>
                    )}
                </div>
            </div>

            {/* Right Sidebar - Dashboard Navigation */}
            <div className="w-72 bg-white border-l shadow-xl p-6 flex flex-col">
                <h3 className="text-sm font-black text-gray-400 uppercase tracking-widest mb-8">Fonctionnalités</h3>
                <nav className="flex-1 space-y-2">
                    {sidebarItems.map((item) => (
                        <button
                            key={item.id}
                            onClick={() => setActiveTab(item.id)}
                            className={`w-full flex items-center gap-3 p-4 rounded-2xl font-bold transition-all ${
                                activeTab === item.id 
                                ? "bg-blue-600 text-white shadow-lg shadow-blue-200" 
                                : "text-gray-600 hover:bg-gray-50"
                            }`}
                        >
                            {item.icon} {item.label}
                        </button>
                    ))}
                </nav>
            </div>
        </div>
    );
};

export default ChannelDashboard;
