import { useState } from "react";
import { List, Search, UserPlus, Power } from "@boxicons/react";
import Icorn from "./Icorn";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export const Button = () => {
    const { user, logout } = useAuth();
    const navigate = useNavigate();
    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);

    const handleLogout = () => {
        logout();
        navigate("/");
    };

    return (
        <>
            <header className="flex justify-between items-center text-slate-900 py-4 px-8 md:px-20 bg-white/80 backdrop-blur-md border-b border-slate-100 sticky top-0 z-[100] transition-all">
                <div className="flex items-center gap-2">
                    <div className="p-2 bg-indigo-600 rounded-xl shadow-lg shadow-indigo-200">
                        <Icorn />
                    </div>
                    <h2 className="font-black text-xl tracking-tight text-indigo-900">
                        LUKO<span className="text-rose-500">LIVE</span>
                    </h2>
                </div>

                <ul className="hidden xl:flex items-center gap-8 font-bold text-sm uppercase tracking-wide">
                    <li className="text-slate-600 hover:text-indigo-600 transition-colors cursor-pointer">
                        <Link to="/">Accueil</Link>
                    </li>
                    <li className="text-slate-600 hover:text-indigo-600 transition-colors cursor-pointer">
                        <Link to="Chaines">Chaines</Link>
                    </li>
                    <li className="text-slate-600 hover:text-indigo-600 transition-colors cursor-pointer">
                        <Link to="Emission">Emission</Link>
                    </li>
                    <li className="text-slate-600 hover:text-indigo-600 transition-colors cursor-pointer">
                        <Link to="Categorie">Catégories</Link>
                    </li>
                    {user?.is_admin && (
                        <li className="bg-rose-50 text-rose-600 px-3 py-1 rounded-full text-xs font-black border border-rose-100 animate-pulse">
                            <Link to="/AdminDashboard">ADMIN</Link>
                        </li>
                    )}
                </ul>

                <div className="relative hidden md:flex items-center justify-center gap-4">
                    <div className="relative group">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-500 transition-colors" size={18} />
                        <input
                            type="text"
                            placeholder="Rechercher..."
                            className="py-2 pl-10 pr-4 rounded-full bg-slate-100 border-none focus:ring-2 focus:ring-indigo-500/20 focus:bg-white w-48 focus:w-64 transition-all outline-none text-sm"
                        />
                    </div>

                    {user ? (
                        <div className="flex items-center gap-3 relative">
                            <div 
                                className="flex items-center gap-2 bg-indigo-50 pl-2 pr-4 py-1.5 rounded-full border border-indigo-100 cursor-pointer hover:bg-indigo-100 transition shadow-sm"
                                onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                            >
                                <div className="w-8 h-8 rounded-full bg-indigo-600 text-white flex items-center justify-center font-bold text-sm shadow-inner">
                                    {user.username.charAt(0).toUpperCase()}
                                </div>
                                <span className="font-bold text-slate-800 text-sm">{user.username}</span>
                            </div>

                            {isUserMenuOpen && (
                                <div className="absolute top-full right-0 mt-3 w-56 bg-white rounded-2xl shadow-2xl border border-slate-100 py-2 overflow-hidden animate-in fade-in slide-in-from-top-2 duration-200">
                                    <div className="px-4 py-2 border-b border-slate-50 mb-1">
                                        <p className="text-xs text-slate-400 font-medium">Connecté en tant que</p>
                                        <p className="text-sm font-bold text-slate-900 truncate">{user.email || user.username}</p>
                                    </div>
                                    <button 
                                        onClick={handleLogout}
                                        className="w-full flex items-center gap-3 px-4 py-2.5 text-rose-600 hover:bg-rose-50 transition font-bold text-sm"
                                    >
                                        <Power size={18} /> Se déconnecter
                                    </button>
                                </div>
                            )}
                        </div>
                    ) : (
                        <div className="flex gap-3">
                            <Link to="PageLogin" className="text-slate-600 font-bold text-sm px-4 py-2 hover:text-indigo-600 transition">
                                Connexion
                            </Link>
                            <Link to="Pageconnexion" className="bg-indigo-600 text-white rounded-full px-6 py-2 text-sm font-bold shadow-lg shadow-indigo-200 hover:bg-indigo-700 hover:-translate-y-0.5 transition-all active:scale-95">
                                Rejoindre
                            </Link>
                        </div>
                    )}
                </div>

                <i className="bx bx-menu xl:hidden block text-2xl cursor-pointer" onClick={() => setIsMenuOpen(!isMenuOpen)}>
                    <List />
                </i>

                {isMenuOpen && (
                    <div className="absolute xl:hidden top-24 left-0 w-full bg-white flex flex-col items-center font-semibold text-lg shadow-lg">
                        <li className="list-none w-full text-center p-4 hover:bg-sky-400 hover:text-white transition-all cursor-pointer">
                            <Link to="/" onClick={() => setIsMenuOpen(false)}>Accueil</Link>
                        </li>
                        <li className="list-none w-full text-center p-4 hover:bg-sky-400 hover:text-white transition-all cursor-pointer">
                            <Link to="Chaines" onClick={() => setIsMenuOpen(false)}>Chaines</Link>
                        </li>
                        <li className="list-none w-full text-center p-4 hover:bg-sky-400 hover:text-white transition-all cursor-pointer">
                            <Link to="Emission" onClick={() => setIsMenuOpen(false)}>Emission</Link>
                        </li>
                        <li className="list-none w-full text-center p-4 hover:bg-sky-400 hover:text-white transition-all cursor-pointer">
                            <Link to="Categorie" onClick={() => setIsMenuOpen(false)}>Catégories</Link>
                        </li>
                        {user ? (
                            <li 
                                className="list-none w-full text-center p-4 text-red-600 hover:bg-red-50 transition-all cursor-pointer"
                                onClick={handleLogout}
                            >
                                Se déconnecter
                            </li>
                        ) : (
                            <>
                                <li className="list-none w-full text-center p-4 hover:bg-blue-400 hover:text-white transition-all cursor-pointer">
                                    <Link to="PageLogin" onClick={() => setIsMenuOpen(false)}>Connexion</Link>
                                </li>
                                <li className="list-none w-full text-center p-4 hover:bg-red-400 hover:text-white transition-all cursor-pointer">
                                    <Link to="Pageconnexion" onClick={() => setIsMenuOpen(false)}>Créer un compte</Link>
                                </li>
                            </>
                        )}
                    </div>
                )}
            </header>
        </>
    );
};