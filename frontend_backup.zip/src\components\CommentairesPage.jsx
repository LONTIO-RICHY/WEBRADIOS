import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

function CommentairesPage() {
  const navigate = useNavigate();

  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState("");
  const [erreur, setErreur] = useState("");

  const token = localStorage.getItem("token");
  const IP_LOCALE = "127.0.0.1"; // Remplace par ton IP locale si besoin

  useEffect(() => {
    fetchComments();
  }, []);

  const fetchComments = async () => {
    try {
      const response = await axios.get(`http://${IP_LOCALE}:8000/api/comments`);
      setComments(response.data);
    } catch (err) {
      console.error("Impossible de charger les messages", err);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setErreur("");

    if (!token) {
      setErreur("Vous devez être connecté pour participer à la discussion.");
      return;
    }

    if (newComment.trim() === "") {
      return;
    }

    try {
      await axios.post(
        `http://${IP_LOCALE}:8000/api/comments`,
        { content: newComment },
        { headers: { Authorization: `Bearer ${token}` } }
      );

      setNewComment("");
      fetchComments(); // Recharger la discussion
    } catch (err) {
      setErreur(err.response?.data?.detail || "Une erreur est survenue.");
    }
  };

  return (
    <div className="min-h-screen bg-red-50 p-8 flex flex-col items-center">
      
      <button 
        onClick={() => navigate(-1)} 
        className="self-start mb-6 bg-white text-gray-700 px-4 py-2 rounded-lg shadow hover:bg-gray-100 transition font-semibold"
      >
        ← Retour à la Radio
      </button>

      <div className="w-full max-w-2xl bg-white p-6 rounded-2xl shadow-xl space-y-6 flex flex-col h-[80vh]">
        <h1 className="text-2xl font-bold text-blue-600 text-center border-b pb-4">
          Discussion Globale 💬
        </h1>

        {erreur && <div className="bg-red-100 text-red-700 p-3 rounded-lg text-sm">{erreur}</div>}

        {/* LISTE DES DISCUSSIONS (Prend le maximum de place) */}
        <div className="flex-1 overflow-y-auto space-y-3 pr-2">
          {comments.map((comment) => (
            <div key={comment.id} className="p-3 bg-gray-50 rounded-xl border border-gray-100 shadow-sm">
              <div className="flex justify-between items-center mb-1">
                <span className="font-extrabold text-blue-600 text-sm">@{comment.username}</span>
                <span className="text-[10px] text-gray-400">
                  {new Date(comment.created_at).toLocaleDateString("fr-FR", {
                    hour: "2-digit",
                    minute: "2-digit"
                  })}
                </span>
              </div>
              <p className="text-gray-700 text-sm whitespace-pre-line">{comment.content}</p>
            </div>
          ))}

          {comments.length === 0 && (
            <p className="text-gray-500 text-center italic text-sm py-4">
              Aucun message. Lancez la discussion !
            </p>
          )}
        </div>

        {/* CHAMP DE SAISIE EN BAS (Comme une application de messagerie) */}
        <form onSubmit={handleSubmit} className="flex space-x-2 border-t pt-4">
          <input
            type="text"
            placeholder="Écrivez un message aux autres auditeurs..."
            value={newComment}
            onChange={(e) => setNewComment(e.target.value)}
            className="flex-1 p-3 border rounded-xl outline-none focus:ring-2 focus:ring-blue-500 text-sm bg-gray-50"
          />
          <button 
            type="submit" 
            className="bg-blue-600 text-white px-6 py-3 rounded-xl font-semibold hover:bg-blue-700 transition text-sm"
          >
            Envoyer 
          </button>
        </form>

      </div>
    </div>
  );
}

export default CommentairesPage;